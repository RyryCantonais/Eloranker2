import { Injectable } from '@nestjs/common';
import { PlayersService } from '../players/players.service';
import { RankingService } from '../ranking/ranking.service';

const K_FACTOR = 32; // Coefficient de pondération

@Injectable()
export class MatchesService {
  constructor(
    private readonly playersService: PlayersService,
    private readonly rankingService: RankingService,
  ) {}

  processMatch(winnerId: string, loserId: string, isDraw: boolean) {
    const player1 = this.playersService.findOne(winnerId);
    const player2 = this.playersService.findOne(loserId);

    if (!player1 || !player2) {
      throw new Error('Player not found');
    }

    // Calcul des nouveaux ranks
    const { newRank1, newRank2 } = this.calculateNewRanks(
      player1.rank,
      player2.rank,
      isDraw ? 0.5 : 1, // Résultat pour player1
      isDraw ? 0.5 : 0  // Résultat pour player2
    );

    // Mise à jour
    this.playersService.updateRank(winnerId, newRank1);
    this.playersService.updateRank(loserId, newRank2);

    // Notifier les abonnés SSE
    this.rankingService.emitUpdate(player1);
    this.rankingService.emitUpdate(player2);

    return {
      winner: this.playersService.findOne(winnerId),
      loser: this.playersService.findOne(loserId),
    };
  }

  private calculateNewRanks(rank1: number, rank2: number, result1: number, result2: number) {
    const prob1 = this.calculateWinProbability(rank1, rank2);
    const prob2 = 1 - prob1;

    return {
      newRank1: rank1 + K_FACTOR * (result1 - prob1),
      newRank2: rank2 + K_FACTOR * (result2 - prob2),
    };
  }

  private calculateWinProbability(rankA: number, rankB: number): number {
    return 1 / (1 + Math.pow(10, (rankB - rankA) / 400));
  }
}